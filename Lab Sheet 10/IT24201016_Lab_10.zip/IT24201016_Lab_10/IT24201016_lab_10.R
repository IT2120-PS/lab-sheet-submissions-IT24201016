setwd("C:\\Users\\it24201016\\Desktop\\IT24201016_Lab_10")
getwd()

observed <- c(55,62,43,46,50)
prob <- c(.2,.2,.2,.2,.2)

chisq.test(x=observed, p=prob)

file_path <- "http://www.sthda.com/sthda/RDoc/data/housetasks.txt"

housetasks <- read.delim(file_path, row.names = 1)
housetasks

chisq <- chisq.test(housetasks)
chisq


#exercise

data <- read.csv("Data.csv", header = TRUE)




print("Observed data from CSV file:")
print(data)

observed <- c(55, 62, 43, 46)
prob <- c(0.25, 0.25, 0.25, 0.25)

chisq.test(x = observed, p = prob)

#The p-value is 0.1525, which is greater than the typical significance level of 0.05.
#Therefore, we fail to reject the null hypothesis.